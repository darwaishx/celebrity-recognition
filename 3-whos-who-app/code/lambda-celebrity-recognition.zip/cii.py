from __future__ import print_function

import uuid
import json
import urllib
import os
import boto3
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
import time
import io
from botocore.exceptions import ClientError
from threading import Thread
import base64
from decimal import Decimal
import json

class Face:
    Identified = False
    Exception = ""
    Id = ""
    Name = ""
    MatchConfidence = 0.0
    Urls = ""

    RekIdentified = False
    Exception = ""
    RekId = ""
    RekName = ""
    RekMatchConfidence = 0.0
    RekUrls = ""

    BoundingBox = None
    Coordinates = None

    def __repr__(self):
        return "Id: {0}, Name: {1}, Urls: {2}, MatchConfidence: {3}, BB: {4}, Cord: {5}".format(self.Id, self.Name, self.Urls, self.MatchConfidence, self.BoundingBox, self.Coordinates)

    def __str__(self):
        return "Id: {0}, Name: {1}, Urls: {2}, MatchConfidence: {3}, BB: {4}, Cord: {5}".format(self.Id, self.Name, self.Urls, self.MatchConfidence, self.BoundingBox, self.Coordinates)

class CelebrityRecognizer(Thread):

    def __init__(self, imageBytes, face):
        ''' Constructor. '''
        Thread.__init__(self)
        self.imageBytes = imageBytes
        self.face = face

    def run(self):
        #print("Starting CelebrityRecognizer thread : {0}, Face ID: {1}".format(self.getName(), self.face.RekId))

        rekognitionClient = boto3.client('rekognition')

        try:
            celebrities = rekognitionClient.recognize_celebrities(
                Image={
                    'Bytes': self.imageBytes
                },
            )

            if(len(celebrities['CelebrityFaces']) > 0):
                celebrity = celebrities['CelebrityFaces'][0]
                self.face.RekId = celebrity['Id']
                self.face.RekName = celebrity['Name']
                self.face.RekMatchConfidence = celebrity['MatchConfidence']
                self.face.RekUrls = celebrity['Urls']
                self.face.RekIdentified = True

        except Exception as e:
            self.face.RekError = e

        #print("Finished CelebrityRecognizer thread : {0}, Face ID: {1}".format(self.getName(), self.face.RekId))

class FaceProcessor(Thread):

    def __init__(self, image, imageBytes, face):
        ''' Constructor. '''
        Thread.__init__(self)
        self.image = image
        self.imageBytes = imageBytes
        self.face = face

    def calculateCoordinates(self, left, top, width, height, imageWidth, imageHeight, hf, vf):
        x1 = int(left * imageWidth)-hf
        y1 = int(top * imageHeight)-hf
        x2 = int(left * imageWidth + width * imageWidth)+vf
        y2 = int(top * imageHeight + height * imageHeight)+vf
        if x1 < 0 : x1=0
        if y1 < 0 : y1=0
        if x2 < 0 : x2=imageWidth
        if y2 < 0 : y2=imageHeight
        return (x1,y1,x2,y2)

    def getCelebrityDetails(self, id, dynamoClient, tableName):
        print("Table: " + tableName)
        print("Looking for DDB Id: " + id)
        ddbTable = dynamoClient.Table(tableName)
        response = ddbTable.get_item(
                Key={
                    'id': id
                },
                AttributesToGet=['name', 'url']
            )

        print(response)

        if 'Item' in response:
            return response['Item']
        else:
            return None

    def searchFaceByImage(self, imageBinary, rekognitionClient, collectionName):

        response = rekognitionClient.search_faces_by_image(
            CollectionId=collectionName,
            Image={
                'Bytes':imageBinary
                },
            FaceMatchThreshold = 85
            )
        print('In Search Face By Image')
        print(response)

        if len(response['FaceMatches']) > 0:
            return response['FaceMatches'][0]['Face']['ExternalImageId'],response['FaceMatches'][0]['Face']['Confidence']
        else:
            return None


    def recognizeCustomCelebrity(self, image, face, rekognitionClient, collectionName, dynamoClient, dynamoTable):

        try:
            result = self.searchFaceByImage(image, rekognitionClient, collectionName)

            if(result is not None):
                face.Id = result[0]
                face.MatchConfidence = result[1]
                print("Recognized: " + str(face.Id))

                cDetail = self.getCelebrityDetails(face.Id, dynamoClient, dynamoTable)
                if(cDetail is not None):
                    face.Name = cDetail['name']
                    face.Urls = cDetail['url']
                    face.Identified = True
                    print("Recognized: " + str(face.Name))

        except Exception as e:
            print(e)
            face.Error = e
            pass

    def identifyFace(self, image, IMAGE_FORMAT, face, rekognitionClient, collectionName, dynamoClient, dynamoTable):

        #Crop face
        image_crop = image.crop(face.Coordinates)
        stream2 = BytesIO()
        image_crop.save(stream2,format=IMAGE_FORMAT)
        imageBinary = stream2.getvalue()
        stream2.close()

        #Save cropped face on local disk
        #fileName = "images/" + self.getName() + ".jpg"
        #image_crop.save(fileName,format=IMAGE_FORMAT)

        #Rekognize using Rekognition API in a different thread
        t = CelebrityRecognizer(imageBinary, face)
        #t.setName(str(i))
        t.start()

        #Rekognize using custom collection
        try:
            self.recognizeCustomCelebrity(imageBinary, face, rekognitionClient, collectionName, dynamoClient, dynamoTable)
        except Exception as e:
            face.Identified = False
            face.Error = e

        t.join()

        if((not face.Identified) and face.RekIdentified and face.RekMatchConfidence > 85):
            #Additional logic can be use to see which one has higher confidence and take that result
            face.Id = face.RekId
            face.Name = face.RekName
            face.MatchConfidence = face.RekMatchConfidence
            face.Urls = face.RekUrls
            face.Identified = face.RekIdentified

    def run(self):
        #print("Starting thread : {0}, Face ID: {1}, RekFace ID: {2}".format(self.getName(), self.face.Id, self.face.RekId))

        dynamoClient = boto3.resource('dynamodb')
        rekognitionClient = boto3.client('rekognition')

        #Replace these with environment variables
        collectionName = "my-celebrities"
        dynamoTable = "my-celebrities"

        hf = 15
        vf = 15

        imageWidth = self.image.size[0]
        imageHeight = self.image.size[1]
        IMAGE_FORMAT = "JPEG"

        #Calculate coordinates
        self.face.Coordinates = self.calculateCoordinates(self.face.BoundingBox['Left'],
                                                          self.face.BoundingBox['Top'],
                                                          self.face.BoundingBox['Width'],
                                                          self.face.BoundingBox['Height'],
                                                          imageWidth,
                                                          imageHeight,
                                                          hf,vf)

        self.identifyFace(self.image, IMAGE_FORMAT, self.face, rekognitionClient, collectionName, dynamoClient, dynamoTable)

        #print("Finished thread : {0}, Face ID: {1}, RekFace ID: {2}".format(self.getName(), self.face.Id, self.face.RekId))


def detectFaces(imageBytes, rekognition):
    response = rekognition.detect_faces(
        Image={
            'Bytes':imageBytes
            },
            Attributes=[
            'DEFAULT']
        )
    all_faces=response['FaceDetails']

    # initialise list object
    faces = []

    # populate list for each face
    for face in all_faces:
        f = Face()
        f.BoundingBox = face['BoundingBox']
        faces.append (f)
    return faces


def getJson(face):
    data = {}

    if(face.Id):
        data['Id'] = face.Id
    if(face.Name):
        data['Name'] = face.Name
    if(face.MatchConfidence):
        data['MatchConfidence'] = face.MatchConfidence
    if(face.Urls):
        data['Urls'] = face.Urls
    if(face.BoundingBox):
        data['BoundingBox'] = face.BoundingBox

    return data

def processImage(data):

    #Get Image
    image = Image.open(BytesIO(base64.b64decode(data)))
    #img = base64.b64decode(image)
    ba = io.BytesIO()
    image.save(ba, format="JPEG")
    imageBytes = ba.getvalue()

    imageWidth = image.size[0]
    imageHeight = image.size[1]

    #Detect faces
    rekognitionClient = boto3.client('rekognition')
    faces = detectFaces(imageBytes, rekognitionClient)

    threads = []

    i = 1
    for face in faces:
        t = FaceProcessor(image, imageBytes, face)
        t.setName(str(i))
        threads.append(t)
        i = i + 1

    print("Faces: " + str(i-1))

    for thr in threads:
        thr.start()

    for thr in threads:
        thr.join()

    facesJson = {'CelebrityFaces': []}
    fi = 0
    for face in faces:
        if(face.Identified):
            facesJson['CelebrityFaces'].append(getJson(face))
            fi = fi + 1
            print(face)

    print("Identified faces: " + str(fi))

    foutput = json.dumps(facesJson)

    return foutput

def recognizeCelebrities(event, context):
    rekognition = boto3.client('rekognition')

    try:
        image = event['body']

        celebrities = processImage(image)
    except:
        celebrities = 'Operation failed.'

    return {
    "isBase64Encoded": False,
    "statusCode": 200,
    "body": json.dumps(celebrities),
    "headers": {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
      }
    }
