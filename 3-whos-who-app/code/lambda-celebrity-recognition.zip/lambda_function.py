from __future__ import print_function

import uuid
import json
import urllib
import os
import boto3
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
import time
import io
from botocore.exceptions import ClientError
from threading import Thread
import base64
from decimal import Decimal
import json
import cii

def lambda_handler(event, context):

    print("starting lambda...")
    print(event)

    if(event['resource'] == '/GetCelebrityRecognition'):
        bucketName = os.environ['s3_bucket']
        v = event['queryStringParameters']['v']
        s3 = boto3.resource('s3')
        obj = s3.Object(bucketName,v + "-results.json")
        cdata = obj.get()['Body'].read().decode()

        return {
            "isBase64Encoded": False,
            "statusCode": 200,
            "body": json.dumps(cdata),
            "headers": {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
                }
            }
    else:
        return cii.recognizeCelebrities(event, context)
